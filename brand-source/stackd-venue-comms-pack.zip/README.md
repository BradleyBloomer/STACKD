# STACKD Venue Communications pack

Files:
- `machine-master.png` — untouched approved render.
- `machine-bezel-mask.png` — same render with only the screen opening transparent.
- `screen-hole-alpha.png` — alpha guide.
- `venue-comms-demo.html` — self-contained browser demo that rotates example adverts and projects them into the screen using two affine triangles.

Screen quad in the original 1122 x 1402 image:
- TL: (475, 452)
- TR: (658, 460)
- BR: (658, 838)
- BL: (475, 841)

Integration order:
1. Draw `machine-master.png`.
2. Draw/project the current advert into the screen quad.
3. Draw `machine-bezel-mask.png` on top.

This keeps the machine, wall, lighting, logo, payment terminal and shadows unchanged. Only the display content is replaced.
